<?php
$dbhost="localhost";
$dbuser="suyuwen1";
$dbpassword="789456123";
$dbname="idaydaybuy";
$dbdk="3306";
?>